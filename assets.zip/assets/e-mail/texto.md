### SENTIMOS SUA FALTA NO VESTIBULAR DA METODISTA

Mas ainda dá tempo de realizar a prova de redação e estudar em 2020 na melhor universidade particular do ABC.

Inscreva-se gratuitamente pelo 11 4366-5000 ou no site, compareça no dia da prova e, após ser aprovado, faça sua matrícula com 50% de desconto em janeiro e 100% em fevereiro.

[Inscreva-se](http://vestibularmetodista.com.br/)